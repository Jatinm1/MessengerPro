﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ChatApp.Application.DTOs.Chat
{
    public record SendMessageRequest(Guid ToUserId, string Body);

}
