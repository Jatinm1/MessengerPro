﻿using ChatApp.Application.Common;
using ChatApp.Application.DTOs.Chat;
using ChatApp.Application.DTOs.Group;
using ChatApp.Domain.Enums;

namespace ChatApp.Application.Interfaces.IServices;

public interface IChatService
{
    Task<Result<MessageSentDto>> SendDirectMessageAsync(Guid fromUserId, Guid toUserId, string body, string? contentType = "text", string? mediaUrl = null);
    Task<Result<MessageSentDto>> SendGroupMessageAsync(Guid conversationId, Guid senderId, string body, string? contentType = "text", string? mediaUrl = null);
    Task<IEnumerable<ContactDto>> GetContactsAsync(Guid userId);
    Task<IEnumerable<DTOs.Chat.MessageWithStatusDto>> GetChatHistoryAsync(Guid conversationId, Guid userId, int page, int pageSize);
    Task<Guid> GetOrCreateConversationAsync(Guid userA, Guid userB);
    Task<IEnumerable<Guid>> MarkMessagesAsReadAsync(Guid conversationId, Guid userId, long lastReadMessageId);

    // Group management
    Task<Result<GroupDetailsDto>> CreateGroupAsync(Guid creatorUserId, string groupName, string? groupPhotoUrl, List<Guid> memberUserIds);
    Task<GroupDetailsDto?> GetGroupDetailsAsync(Guid conversationId, Guid userId);
    Task<Result<string>> AddGroupMemberAsync(Guid conversationId, Guid userId, Guid addedBy);
    Task<Result<string>> RemoveGroupMemberAsync(Guid conversationId, Guid userId, Guid removedBy);
    Task<Result<string>> LeaveGroupAsync(Guid conversationId, Guid userId);
    Task<bool> IsUserAdminAsync(Guid conversationId, Guid userId);
    Task<Result<string>> TransferAdminAsync(Guid conversationId, Guid oldAdminId, Guid newAdminId);
    Task<Result<string>> UpdateGroupInfoAsync(Guid conversationId, Guid userId, string? groupName, string? groupPhotoUrl);
    Task<Result<string>> DeleteGroupAsync(Guid conversationId, Guid userId);

    // Message operations
    Task UpdateMessageStatusAsync(long messageId, Guid userId, string status);
    Task<Guid?> GetSenderIdByMessageIdAsync(long messageId);
    Task<IEnumerable<DTOs.Chat.MessageStatusDto>> GetMessageStatusAsync(long messageId);
    Task<Result<string>> DeleteMessageAsync(long messageId, Guid userId, bool deleteForEveryone);
    Task<Result<string>> EditMessageAsync(long messageId, Guid userId, string newBody);
    Task<Result<long>> ForwardMessageAsync(long originalMessageId, Guid forwardedBy, Guid targetConversationId);
    Task<Guid> GetConversationIdByMessageIdAsync(long messageId);
    Task<List<Guid>> GetConversationMembersAsync(Guid conversationId);
}