﻿using ChatApp.Application.DTOs.Chat;
using ChatApp.Application.DTOs.Group;
using ChatApp.Application.Interfaces.IServices;
using Microsoft.AspNetCore.SignalR;

namespace ChatApp.Infrastructure.Services;

public class NotificationService : INotificationService
{
    private readonly IHubContext<ChatHub> _hubContext;

    public NotificationService(IHubContext<ChatHub> hubContext)
    {
        _hubContext = hubContext;
    }

    public async Task NotifyMessageSentAsync(MessageSentDto message)
    {
        var payload = new
        {
            messageId = message.MessageId,
            conversationId = message.ConversationId,
            fromUserId = message.FromUserId,
            fromUserName = message.FromUserName,
            fromDisplayName = message.FromDisplayName,
            body = message.Body,
            contentType = message.ContentType,
            mediaUrl = message.MediaUrl,
            createdAtUtc = message.CreatedAtUtc,
            messageStatus = message.MessageStatus
        };

        // Send to all recipients
        foreach (var recipientId in message.RecipientIds)
        {
            await _hubContext.Clients.Group($"user:{recipientId}")
                .SendAsync("messageReceived", payload);
        }

        // Confirm to sender
        await _hubContext.Clients.Group($"user:{message.FromUserId}")
            .SendAsync("messageSent", payload);
    }

    public async Task NotifyMessageStatusUpdatedAsync(long messageId, Guid conversationId, string status)
    {
        await _hubContext.Clients.All.SendAsync("messageStatusUpdated", new
        {
            messageId,
            conversationId,
            status
        });
    }

    public async Task NotifyGroupCreatedAsync(GroupDetailsDto groupDetails)
    {
        foreach (var member in groupDetails.Members)
        {
            await _hubContext.Clients.Group($"user:{member.UserId}")
                .SendAsync("groupCreated", groupDetails);
        }
    }

    public async Task NotifyGroupMemberAddedAsync(Guid conversationId, Guid addedUserId, Guid addedBy)
    {
        await _hubContext.Clients.Group($"user:{addedUserId}")
            .SendAsync("addedToGroup", new { conversationId, addedBy });

        // Notify other members
        await _hubContext.Clients.Group($"conversation:{conversationId}")
            .SendAsync("groupMemberAdded", new { conversationId, addedUserId, addedBy });
    }

    public async Task NotifyGroupMemberRemovedAsync(Guid conversationId, Guid removedUserId, Guid removedBy)
    {
        await _hubContext.Clients.Group($"user:{removedUserId}")
            .SendAsync("removedFromGroup", new { conversationId, removedBy });

        await _hubContext.Clients.Group($"conversation:{conversationId}")
            .SendAsync("groupMemberRemoved", new { conversationId, removedUserId, removedBy });
    }

    public async Task NotifyGroupDeletedAsync(Guid conversationId, string groupName, Guid deletedBy, List<Guid> memberIds)
    {
        foreach (var memberId in memberIds)
        {
            await _hubContext.Clients.Group($"user:{memberId}")
                .SendAsync("groupDeleted", new
                {
                    conversationId,
                    groupName,
                    deletedBy
                });
        }
    }

    public async Task NotifyMessageDeletedAsync(long messageId, Guid conversationId, Guid deletedBy, bool deleteForEveryone, List<Guid> memberIds)
    {
        foreach (var memberId in memberIds)
        {
            await _hubContext.Clients.Group($"user:{memberId}")
                .SendAsync("messageDeleted", new
                {
                    messageId,
                    conversationId,
                    deletedBy,
                    deleteForEveryone
                });
        }
    }

    public async Task NotifyMessageEditedAsync(long messageId, Guid conversationId, string newBody, Guid editedBy, List<Guid> memberIds)
    {
        foreach (var memberId in memberIds)
        {
            await _hubContext.Clients.Group($"user:{memberId}")
                .SendAsync("messageEdited", new
                {
                    messageId,
                    conversationId,
                    newBody,
                    editedBy,
                    editedAtUtc = DateTime.UtcNow
                });
        }
    }
}