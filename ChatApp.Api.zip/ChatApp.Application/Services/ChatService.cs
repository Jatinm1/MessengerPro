﻿using ChatApp.Application.Common;
using ChatApp.Application.DTOs.Chat;
using ChatApp.Application.DTOs.Group;
using ChatApp.Application.Interfaces.IRepositories;
using ChatApp.Application.Interfaces.IServices;

namespace ChatApp.Application.Services;

public class ChatService : IChatService
{
    private readonly IChatRepository _chatRepository;
    private readonly IFriendRepository _friendRepository;
    private readonly IUserRepository _userRepository;
    private readonly IGroupRepository _groupRepository;

    public ChatService(
        IChatRepository chatRepository,
        IFriendRepository friendRepository,
        IUserRepository userRepository,
        IGroupRepository groupRepository)
    {
        _chatRepository = chatRepository;
        _friendRepository = friendRepository;
        _userRepository = userRepository;
        _groupRepository = groupRepository;
    }

    public async Task<Result<MessageSentDto>> SendDirectMessageAsync(
        Guid fromUserId,
        Guid toUserId,
        string body,
        string? contentType = "text",
        string? mediaUrl = null)
    {
        // Validate friendship
        var areFriends = await _friendRepository.AreFriendsAsync(fromUserId, toUserId);
        if (!areFriends)
        {
            return Result<MessageSentDto>.Failure("You can only message friends");
        }

        // Validate message content
        if (string.IsNullOrWhiteSpace(body) && string.IsNullOrWhiteSpace(mediaUrl))
        {
            return Result<MessageSentDto>.Failure("Message cannot be empty");
        }

        // Create or get conversation
        var conversationId = await _chatRepository.GetOrCreateDirectConversationAsync(fromUserId, toUserId);

        // Save message
        var messageId = await _chatRepository.SaveMessageAsync(
            conversationId,
            fromUserId,
            body,
            contentType ?? "text",
            mediaUrl);

        // Get sender details
        var sender = await _userRepository.GetByIdAsync(fromUserId);

        // Create response DTO
        var messageSentDto = new MessageSentDto(
            MessageId: messageId,
            ConversationId: conversationId,
            FromUserId: fromUserId,
            FromUserName: sender?.UserName ?? "Unknown",
            FromDisplayName: sender?.DisplayName ?? "Unknown",
            Body: body,
            ContentType: contentType ?? "text",
            MediaUrl: mediaUrl,
            CreatedAtUtc: DateTime.UtcNow,
            MessageStatus: "Sent",
            RecipientIds: new List<Guid> { toUserId }
        );

        return Result<MessageSentDto>.Success(messageSentDto);
    }

    public async Task<Result<MessageSentDto>> SendGroupMessageAsync(
        Guid conversationId,
        Guid senderId,
        string body,
        string? contentType = "text",
        string? mediaUrl = null)
    {
        // Validate group membership
        var groupDetails = await _chatRepository.GetGroupDetailsAsync(conversationId, senderId);
        if (groupDetails == null)
        {
            return Result<MessageSentDto>.Failure("You are not a member of this group");
        }

        // Validate message content
        if (string.IsNullOrWhiteSpace(body) && string.IsNullOrWhiteSpace(mediaUrl))
        {
            return Result<MessageSentDto>.Failure("Message cannot be empty");
        }

        // Save message
        var messageId = await _chatRepository.SaveMessageAsync(
            conversationId,
            senderId,
            body,
            contentType ?? "text",
            mediaUrl);

        // Get sender details
        var sender = await _userRepository.GetByIdAsync(senderId);

        // Get recipient IDs (all members except sender)
        var recipientIds = groupDetails.Members
            .Where(m => m.UserId != senderId)
            .Select(m => m.UserId)
            .ToList();

        // Create response DTO
        var messageSentDto = new MessageSentDto(
            MessageId: messageId,
            ConversationId: conversationId,
            FromUserId: senderId,
            FromUserName: sender?.UserName ?? "Unknown",
            FromDisplayName: sender?.DisplayName ?? "Unknown",
            Body: body,
            ContentType: contentType ?? "text",
            MediaUrl: mediaUrl,
            CreatedAtUtc: DateTime.UtcNow,
            MessageStatus: "Sent",
            RecipientIds: recipientIds
        );

        return Result<MessageSentDto>.Success(messageSentDto);
    }

    public async Task<IEnumerable<ContactDto>> GetContactsAsync(Guid userId)
    {
        return await _chatRepository.GetContactsAsync(userId);
    }

    public async Task<IEnumerable<MessageWithStatusDto>> GetChatHistoryAsync(
        Guid conversationId,
        Guid userId,
        int page,
        int pageSize)
    {
        // Validate page parameters
        if (page < 1) page = 1;
        if (pageSize < 1 || pageSize > 100) pageSize = 20;

        return await _chatRepository.GetMessagesWithStatusAsync(conversationId, userId, page, pageSize);
    }

    public async Task<Guid> GetOrCreateConversationAsync(Guid userA, Guid userB)
    {
        return await _chatRepository.GetOrCreateDirectConversationAsync(userA, userB);
    }

    public async Task<IEnumerable<Guid>> MarkMessagesAsReadAsync(
        Guid conversationId,
        Guid userId,
        long lastReadMessageId)
    {
        return await _chatRepository.MarkMessagesAsReadAsync(conversationId, userId, lastReadMessageId);
    }

    // ========================================
    // GROUP MANAGEMENT
    // ========================================

    public async Task<Result<GroupDetailsDto>> CreateGroupAsync(
        Guid creatorUserId,
        string groupName,
        string? groupPhotoUrl,
        List<Guid> memberUserIds)
    {
        // Validate group name
        if (string.IsNullOrWhiteSpace(groupName))
        {
            return Result<GroupDetailsDto>.Failure("Group name is required");
        }

        if (groupName.Length > 100)
        {
            return Result<GroupDetailsDto>.Failure("Group name must be less than 100 characters");
        }

        // Validate members
        if (memberUserIds == null || memberUserIds.Count == 0)
        {
            return Result<GroupDetailsDto>.Failure("At least one member is required");
        }

        // Creator must be included
        if (!memberUserIds.Contains(creatorUserId))
        {
            memberUserIds.Add(creatorUserId);
        }

        // Create group
        var (conversationId, errorMessage) = await _chatRepository.CreateGroupAsync(
            creatorUserId,
            groupName,
            groupPhotoUrl,
            memberUserIds);

        if (errorMessage != null)
        {
            return Result<GroupDetailsDto>.Failure(errorMessage);
        }

        // Get full group details
        var groupDetails = await _chatRepository.GetGroupDetailsAsync(conversationId, creatorUserId);

        if (groupDetails == null)
        {
            return Result<GroupDetailsDto>.Failure("Failed to retrieve group details");
        }

        return Result<GroupDetailsDto>.Success(groupDetails);
    }

    public async Task<GroupDetailsDto?> GetGroupDetailsAsync(Guid conversationId, Guid userId)
    {
        return await _chatRepository.GetGroupDetailsAsync(conversationId, userId);
    }

    public async Task<Result<string>> AddGroupMemberAsync(
        Guid conversationId,
        Guid userId,
        Guid addedBy)
    {
        // Verify admin permissions
        var isAdmin = await _chatRepository.IsUserAdminAsync(conversationId, addedBy);
        if (!isAdmin)
        {
            return Result<string>.Failure("Only admins can add members");
        }

        var errorMessage = await _chatRepository.AddGroupMemberAsync(conversationId, userId, addedBy);

        if (errorMessage != null)
        {
            return Result<string>.Failure(errorMessage);
        }

        return Result<string>.Success("Member added successfully");
    }

    public async Task<Result<string>> RemoveGroupMemberAsync(
        Guid conversationId,
        Guid userId,
        Guid removedBy)
    {
        // Verify admin permissions
        var isAdmin = await _chatRepository.IsUserAdminAsync(conversationId, removedBy);
        if (!isAdmin)
        {
            return Result<string>.Failure("Only admins can remove members");
        }

        // Cannot remove yourself (use LeaveGroup instead)
        if (userId == removedBy)
        {
            return Result<string>.Failure("Use leave group to remove yourself");
        }

        var errorMessage = await _chatRepository.RemoveGroupMemberAsync(conversationId, userId, removedBy);

        if (errorMessage != null)
        {
            return Result<string>.Failure(errorMessage);
        }

        return Result<string>.Success("Member removed successfully");
    }

    public async Task<Result<string>> LeaveGroupAsync(Guid conversationId, Guid userId)
    {
        var errorMessage = await _chatRepository.LeaveGroupAsync(conversationId, userId);

        if (errorMessage != null)
        {
            return Result<string>.Failure(errorMessage);
        }

        return Result<string>.Success("Left group successfully");
    }

    public async Task<bool> IsUserAdminAsync(Guid conversationId, Guid userId)
    {
        return await _chatRepository.IsUserAdminAsync(conversationId, userId);
    }

    public async Task<Result<string>> TransferAdminAsync(
        Guid conversationId,
        Guid oldAdminId,
        Guid newAdminId)
    {
        // Verify current user is admin
        var isAdmin = await _chatRepository.IsUserAdminAsync(conversationId, oldAdminId);
        if (!isAdmin)
        {
            return Result<string>.Failure("Only admins can transfer admin rights");
        }

        // Verify new admin is a member
        var groupDetails = await _chatRepository.GetGroupDetailsAsync(conversationId, oldAdminId);
        if (groupDetails == null || !groupDetails.Members.Any(m => m.UserId == newAdminId))
        {
            return Result<string>.Failure("New admin must be a group member");
        }

        var errorMessage = await _chatRepository.TransferAdminAsync(conversationId, oldAdminId, newAdminId);

        if (errorMessage != null)
        {
            return Result<string>.Failure(errorMessage);
        }

        return Result<string>.Success("Admin transferred successfully");
    }

    public async Task<Result<string>> UpdateGroupInfoAsync(
        Guid conversationId,
        Guid userId,
        string? groupName,
        string? groupPhotoUrl)
    {
        // Verify admin permissions
        var isAdmin = await _chatRepository.IsUserAdminAsync(conversationId, userId);
        if (!isAdmin)
        {
            return Result<string>.Failure("Only admins can update group info");
        }

        // Validate group name if provided
        if (groupName != null && string.IsNullOrWhiteSpace(groupName))
        {
            return Result<string>.Failure("Group name cannot be empty");
        }

        if (groupName != null && groupName.Length > 100)
        {
            return Result<string>.Failure("Group name must be less than 100 characters");
        }

        var errorMessage = await _chatRepository.UpdateGroupInfoAsync(conversationId, userId, groupName, groupPhotoUrl);

        if (errorMessage != null)
        {
            return Result<string>.Failure(errorMessage);
        }

        return Result<string>.Success("Group updated successfully");
    }

    public async Task<Result<string>> DeleteGroupAsync(Guid conversationId, Guid userId)
    {
        // Verify admin permissions
        var isAdmin = await _chatRepository.IsUserAdminAsync(conversationId, userId);
        if (!isAdmin)
        {
            return Result<string>.Failure("Only admins can delete the group");
        }

        var errorMessage = await _groupRepository.DeleteGroupAsync(conversationId, userId);

        if (errorMessage != null)
        {
            return Result<string>.Failure(errorMessage);
        }

        return Result<string>.Success("Group deleted successfully");
    }

    // ========================================
    // MESSAGE OPERATIONS
    // ========================================

    public async Task UpdateMessageStatusAsync(long messageId, Guid userId, string status)
    {
        await _chatRepository.UpdateMessageStatusAsync(messageId, userId, status);
    }

    public async Task<Guid?> GetSenderIdByMessageIdAsync(long messageId)
    {
        return await _chatRepository.GetSenderIdByMessageIdAsync(messageId);
    }

    public async Task<IEnumerable<MessageStatusDto>> GetMessageStatusAsync(long messageId)
    {
        return await _chatRepository.GetMessageStatusAsync(messageId);
    }

    public async Task<Result<string>> DeleteMessageAsync(
        long messageId,
        Guid userId,
        bool deleteForEveryone)
    {
        var errorMessage = await _chatRepository.DeleteMessageAsync(messageId, userId, deleteForEveryone);

        if (errorMessage != null)
        {
            return Result<string>.Failure(errorMessage);
        }

        return Result<string>.Success("Message deleted successfully");
    }

    public async Task<Result<string>> EditMessageAsync(long messageId, Guid userId, string newBody)
    {
        if (string.IsNullOrWhiteSpace(newBody))
        {
            return Result<string>.Failure("Message cannot be empty");
        }

        var errorMessage = await _chatRepository.EditMessageAsync(messageId, userId, newBody);

        if (errorMessage != null)
        {
            return Result<string>.Failure(errorMessage);
        }

        return Result<string>.Success("Message edited successfully");
    }

    public async Task<Result<long>> ForwardMessageAsync(
        long originalMessageId,
        Guid forwardedBy,
        Guid targetConversationId)
    {
        var (messageId, errorMessage) = await _chatRepository.ForwardMessageAsync(
            originalMessageId,
            forwardedBy,
            targetConversationId);

        if (errorMessage != null || messageId == null)
        {
            return Result<long>.Failure(errorMessage ?? "Failed to forward message");
        }

        return Result<long>.Success(messageId.Value);
    }

    public async Task<Guid> GetConversationIdByMessageIdAsync(long messageId)
    {
        return await _chatRepository.GetConversationIdByMessageIdAsync(messageId);
    }

    public async Task<List<Guid>> GetConversationMembersAsync(Guid conversationId)
    {
        return await _chatRepository.GetConversationMembersAsync(conversationId);
    }
}