﻿namespace ChatApp.Application;

public class Class1
{

}
