﻿namespace ChatApp.Domain;

public class Class1
{

}
