﻿using ChatApp.Application.DTOs.Chat;
using ChatApp.Application.Interfaces.IServices;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Security.Claims;

namespace ChatApp.Api.Controllers;

[ApiController]
[Route("api/[controller]")]
[Authorize]
public class ChatController : ControllerBase
{
    private readonly IChatService _chatService;
    private readonly ICloudinaryService _cloudinaryService;
    private readonly INotificationService _notificationService;

    public ChatController(
        IChatService chatService,
        ICloudinaryService cloudinaryService,
        INotificationService notificationService)
    {
        _chatService = chatService;
        _cloudinaryService = cloudinaryService;
        _notificationService = notificationService;
    }

    private Guid CurrentUserId => Guid.Parse(
        User.FindFirstValue(ClaimTypes.NameIdentifier) ??
        User.FindFirstValue("sub")!);

    [HttpGet("contacts")]
    public async Task<IActionResult> GetContacts()
    {
        var contacts = await _chatService.GetContactsAsync(CurrentUserId);
        return Ok(contacts);
    }

    [HttpGet("history/{conversationId}")]
    public async Task<IActionResult> GetChatHistory(
        Guid conversationId,
        [FromQuery] int page = 1,
        [FromQuery] int pageSize = 20)
    {
        var messages = await _chatService.GetChatHistoryAsync(conversationId, CurrentUserId, page, pageSize);
        return Ok(messages);
    }

    [HttpGet("conversation/{userId}")]
    public async Task<IActionResult> GetOrCreateConversation(Guid userId)
    {
        var conversationId = await _chatService.GetOrCreateConversationAsync(CurrentUserId, userId);
        return Ok(new { conversationId });
    }

    [HttpPost("mark-as-read/{conversationId}")]
    public async Task<IActionResult> MarkAsRead(
        Guid conversationId,
        [FromBody] long lastReadMessageId)
    {
        var affectedSenders = await _chatService.MarkMessagesAsReadAsync(
            conversationId,
            CurrentUserId,
            lastReadMessageId);

        return Ok();
    }

    [HttpPost("message/{messageId}/status")]
    public async Task<IActionResult> UpdateMessageStatus(
        long messageId,
        [FromBody] string status)
    {
        await _chatService.UpdateMessageStatusAsync(messageId, CurrentUserId, status);
        return Ok();
    }

    [HttpGet("message/{messageId}/status")]
    public async Task<IActionResult> GetMessageStatus(long messageId)
    {
        var statuses = await _chatService.GetMessageStatusAsync(messageId);
        return Ok(statuses);
    }

    [HttpPost("message/{messageId}/delete")]
    public async Task<IActionResult> DeleteMessage(
        long messageId,
        [FromBody] DeleteMessageRequest request)
    {
        var result = await _chatService.DeleteMessageAsync(
            messageId,
            CurrentUserId,
            request.DeleteForEveryone);

        if (!result.IsSuccess)
            return BadRequest(new { error = result.Error });

        // Notify via SignalR
        var conversationId = await _chatService.GetConversationIdByMessageIdAsync(messageId);
        var members = await _chatService.GetConversationMembersAsync(conversationId);

        await _notificationService.NotifyMessageDeletedAsync(
            messageId,
            conversationId,
            CurrentUserId,
            request.DeleteForEveryone,
            members);

        return Ok(new { message = result.Value });
    }

    [HttpPut("message/{messageId}/edit")]
    public async Task<IActionResult> EditMessage(
        long messageId,
        [FromBody] EditMessageRequest request)
    {
        var result = await _chatService.EditMessageAsync(messageId, CurrentUserId, request.NewBody);

        if (!result.IsSuccess)
            return BadRequest(new { error = result.Error });

        // Notify via SignalR
        var conversationId = await _chatService.GetConversationIdByMessageIdAsync(messageId);
        var members = await _chatService.GetConversationMembersAsync(conversationId);

        await _notificationService.NotifyMessageEditedAsync(
            messageId,
            conversationId,
            request.NewBody,
            CurrentUserId,
            members);

        return Ok(new { message = result.Value });
    }

    [HttpPost("message/{messageId}/forward")]
    public async Task<IActionResult> ForwardMessage(
        long messageId,
        [FromBody] ForwardMessageRequest request)
    {
        var result = await _chatService.ForwardMessageAsync(
            messageId,
            CurrentUserId,
            request.TargetConversationId);

        if (!result.IsSuccess)
            return BadRequest(new { error = result.Error });

        return Ok(new { messageId = result.Value, message = "Message forwarded successfully" });
    }

    [HttpPost("upload/media")]
    [RequestSizeLimit(50_000_000)]
    public async Task<IActionResult> UploadMedia(IFormFile file)
    {
        if (file == null || file.Length == 0)
            return BadRequest(new { error = "No file uploaded" });

        var contentType = file.ContentType.ToLower();
        var isImage = contentType.StartsWith("image/");
        var isVideo = contentType.StartsWith("video/");

        if (!isImage && !isVideo)
            return BadRequest(new { error = "Only images and videos are allowed" });

        var maxSize = isImage ? 10_000_000 : 50_000_000;
        if (file.Length > maxSize)
            return BadRequest(new { error = $"File size must be less than {maxSize / 1_000_000}MB" });

        try
        {
            using var stream = file.OpenReadStream();
            var (url, publicId, error) = isImage
                ? await _cloudinaryService.UploadImageAsync(stream, file.FileName)
                : await _cloudinaryService.UploadVideoAsync(stream, file.FileName);

            if (error != null)
                return BadRequest(new { error = $"Upload failed: {error}" });

            return Ok(new
            {
                url,
                publicId,
                type = isImage ? "image" : "video",
                contentType = file.ContentType
            });
        }
        catch (Exception ex)
        {
            return StatusCode(500, new { error = $"Upload failed: {ex.Message}" });
        }
    }
}
