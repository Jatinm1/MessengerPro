﻿// ChatApp.Api/Controllers/HomeController.cs
using Microsoft.AspNetCore.Mvc;

[ApiController]
[Route("/")]
public class HomeController : ControllerBase
{
    [HttpGet]
    public IActionResult Index()
        => Ok(new { Message = "ChatApp API is running 🚀", Time = DateTime.UtcNow });
}
