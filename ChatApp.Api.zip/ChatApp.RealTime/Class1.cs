﻿namespace ChatApp.RealTime
{
    public class Class1
    {

    }
}
